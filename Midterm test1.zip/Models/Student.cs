﻿using System.ComponentModel.DataAnnotations;

namespace _200566745.Models

{
    public class Student
    { 
    
        public int StudentId { get; set; }

        [Required]
        [Display(Name = "Prabhjot Singh")]
        public string FirstName { get; set; }

        [Required]
        [Display(Name = "Last Name")]
        public string LastName { get; set; }

        [Required]
        [EmailAddress]
        public string EmailAddress { get; set; }
    }


}
